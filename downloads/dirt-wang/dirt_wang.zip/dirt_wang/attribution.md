Attribution
===========

dirt_wang.png
-------------
* Title: Dirt Wang
* License:
  * [CC-BY-SA 3.0][1]
  * [GNU GPL 3.0][2]
* Author: [Sebastian Riedel][3] (AKA Baŝto)
* Based on
  * Title: dirt
    * License:
      * [CC-BY-SA 3.0][1]
      * [GNU GPL 3.0][2]
    * Author: [Lanea Zimmerman][4] (AKA Sharm)
    * [Source][5]

light.gpl
---------
* License:
  * No license, since lack of originality, otherwise:
  * [CC-BY-SA 3.0][1]
  * [GNU GPL 3.0][2]
* Author: [Sebastian Riedel][3] (AKA Baŝto)
* Based on
  * Title: dirt
    * License:
      * [CC-BY-SA 3.0][1]
      * [GNU GPL 3.0][2]
    * Author: [Lanea Zimmerman][4] (AKA Sharm)
    * [Source][5]


normal.gpl
---------
* License:
  * No license, since lack of originality, otherwise:
  * [CC-BY-SA 3.0][1]
  * [GNU GPL 3.0][2]
* Author: [Sebastian Riedel][3] (AKA Baŝto)
* Based on
  * Title: dirt 2
    * License:
      * [CC-BY-SA 3.0][1]
      * [GNU GPL 3.0][2]
    * Author: [Lanea Zimmerman][4] (AKA Sharm)
    * [Source][5]

dirt_wang.tsx
---------
* License:
  * No license, since lack of originality, otherwise:
  * [CC-BY-SA 3.0][6]
  * [GNU GPL 3.0][2]
* Author: [Sebastian Riedel][3] (AKA Baŝto)
* Made for
  * dirt_wang.png

[1]: http://creativecommons.org/licenses/by-sa/3.0/
[2]: http://www.gnu.org/licenses/gpl-3.0.html
[3]: https://opengameart.org/users/ba%C5%9Dto
[4]: https://opengameart.org/users/sharm
[5]: http://lpc.opengameart.org/static/lpc-style-guide/assets.html#outdoors