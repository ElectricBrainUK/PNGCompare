#!/bin/sh
cd ..
zip dirt_wang.zip dirt_wang/dirt_wang.tsx dirt_wang/light.gpl dirt_wang/normal.gpl dirt_wang/attribution.md dirt_wang/pack.sh