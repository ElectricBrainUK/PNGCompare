#!/bin/sh
strip_base(){
    input=$1
    # allow cin
    if [ -z "${input}" ]; then
        read -r input
    fi
    echo "${input}" | sed "s/lpcp96_\(.*\)/\1/g"
}

usage(){
    echo "Usage:"
    echo "$ $0 [--list] [--help/--usage] lpcp96_<gender>_<eyes>_<emotion>_<hair>_<skincolor>_<haircolor>[_eyebrows][_<specials>...].png"
}

build_portrait(){
    name=$(strip_base "$(basename $1 .png)")
    dir=$(strip_base "$(dirname $1)")
    tmp=./tmp
    mkdir -p "${dir}" "${tmp}"
    if [ -z "${dir}" ]; then
        dir="build/"
    fi

    gender=$(echo ${name} | cut -f1 -d_)
    eyes=$(echo ${name} | cut -f2 -d_)
    emotion=$(echo ${name} | cut -f3 -d_)
    hair=$(echo ${name} | cut -f4 -d_)
    skinc=$(echo ${name} | cut -f5 -d_)
    if [ -z "$skinc" ]; then
        skinc="ivory"
    fi
    hairc=$(echo ${name} | cut -f6 -d_)
    if [ -z "$hairc" ]; then
        hairc="brunet"
    fi
    eyebrows=""
    if [ "$(echo ${name} | cut -f7 -d_)" = "eyebrows" ]; then
        eyebrows="lpcp96_eyebrows.png"
        special=$(echo ${name} | cut -f8- -d_)
    else
        special=$(echo ${name} | cut -f7- -d_)
    fi
    sofar="${tmp}"/lpcp96_${eyes}_${emotion}
    magick convert -background none ${eyebrows} eyes/${gender}/lpcp96_${eyes}.png emotions/lpcp96_${emotion}.png -layers flatten "${sofar}".png
    ./lpc-shell-tools/switchpalette.sh "${sofar}".png "${sofar}"_mask.png palette/ivory_brunet_blue.gpl palette/masked.gpl
    # extract alpha channels
    magick convert "${sofar}"_mask.png -transparent black -alpha extract -transparent white  "${sofar}"_mask_alpha.png
    magick convert hair/${gender}/lpcp96_${hair}.png -alpha extract tmp/lpcp96_${gender}_${hair}_alpha.png
    # combine them
    magick convert -background none tmp/lpcp96_${gender}_${hair}_alpha.png "${sofar}"_mask_alpha.png -layers flatten "${sofar}"_${gender}_${hair}_overlap_alpha.png
    # and apply
    magick convert "${sofar}"_mask.png "${sofar}"_${gender}_${hair}_overlap_alpha.png -background black -alpha Off -compose CopyOpacity -composite PNG8:"${sofar}"_${gender}_${hair}_overlap.png


    sofar="${tmp}"/lpcp96_${gender}_${eyes}_${emotion}_${hair}
    # combine
    magick convert -background none base/lpcp96_${gender}.png "${tmp}"/lpcp96_${eyes}_${emotion}.png hair/${gender}/lpcp96_${hair}.png "${tmp}"/lpcp96_${eyes}_${emotion}_${gender}_${hair}_overlap.png -layers flatten "${sofar}".png

    for i in $(echo ${special} | tr _ ' '); do
        magick convert -background none "${sofar}".png special/lpcp96_$i.png -layers flatten "${sofar}_$i".png
        sofar="${sofar}_$i"
    done

    # switch palettes
    ./lpc-shell-tools/switchpalette.sh ${sofar}.png ${sofar}_${skinc}.png palette/skin/ivory.gpl palette/skin/${skinc}.gpl
    sofar="${sofar}_${skinc}"
    ./lpc-shell-tools/switchpalette.sh ${sofar}.png ${sofar}_${hairc}.png palette/hair/brunet.gpl palette/hair/${hairc}.gpl
    cp "${sofar}_${hairc}".png "$1"
}

get_gender(){
    for i in base/*; do
        basename $i .png | strip_base
    done
}

get_eyes(){
    gender=$1
    for i in eyes/${gender}/*; do
        basename $i .png | strip_base
    done
}

get_emotion(){
    for i in emotions/*; do
        basename $i .png | strip_base
    done
}

get_hair(){
    gender=$1
    for i in hair/${gender}/*; do
        basename $i .png | strip_base
    done
}

get_skincolor(){
    for i in palette/skin/*; do
        basename $i .gpl | strip_base
    done
}

get_haircolor(){
    for i in palette/hair/*; do
        basename $i .gpl | strip_base
    done
}

list(){
    echo "Gender:"
    for i in $(get_gender); do
        echo "- $i"
    done
    echo
    echo "Eyes:"
    echo " Male:"
    for i in $(get_eyes "male"); do
        echo " - $i"
    done
    echo " Female:"
    for i in $(get_eyes "female"); do
        echo " - $i"
    done
    echo
    echo "Emotion:"
    for i in $(get_emotion); do
        echo "- $i"
    done
    echo
    echo "Hair:"
    echo " Male:"
    for i in $(get_hair "male"); do
        echo " - $i"
    done
    echo " Female:"
    for i in $(get_hair "female"); do
        echo " - $i"
    done
    echo
    echo "Skin color:"
    for i in $(get_skincolor); do
        echo "- $i"
    done
    echo
    echo "Hair color:"
    for i in $(get_haircolor); do
        echo "- $i"
    done
    echo
    echo "Special:"
    for i in special/*; do
        echo "- $(basename $i .png | strip_base)"
    done
}

random(){
    gender=$(get_gender | sort -R | head -1)
    eyes=$(get_eyes ${gender} | grep -v "none" | sort -R | head -1)
    emotion=$(get_emotion | sort -R | head -1)
    hair=$(get_hair ${gender} | grep -v "none" | sort -R | head -1)
    # 5% no hair
    if [ "$(shuf -i 1-100 -n 1)" -le "5" ]; then
        hair="none"
    fi
    skinc=$(get_skincolor | sort -R | head -1)
    hairc=$(get_haircolor | sort -R | head -1)
    eyebrows=$(printf "_eyebrows\n_eyebrows\n_eyebrows\n\n" | sort -R | head -1)
    if [ "${hair}" = "none" ]; then
        eyebrows="_eyebrows"
    fi
    filename=build/lpcp96_${gender}_${eyes}_${emotion}_${hair}_${skinc}_${hairc}${eyebrows}.png
    echo "${filename}"
    build_portrait ${filename}
}

case "$1" in
    "--list")
        list
        exit
        ;;
    "--usage"|"--help")
        usage
        exit
        ;;
    "--clean")
        make clean
        exit
        ;;
    "--random")
        random
        exit

esac
while [ "$#" != "0" ]; do
    build_portrait $1
    shift
done