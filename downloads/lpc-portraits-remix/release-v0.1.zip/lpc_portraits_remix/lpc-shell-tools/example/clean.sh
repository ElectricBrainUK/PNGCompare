#!/bin/sh
rm *_{spellcast,thrust,walkcycle,slash,shoot,hurt,gunwalk}.png
rm -r tmp_*/