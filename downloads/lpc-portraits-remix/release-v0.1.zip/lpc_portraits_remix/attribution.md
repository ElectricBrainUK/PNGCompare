This submission [“[LPC] Portraits Remix”][lpcport] is licensed under [CC BY 4.0][cc]

All changes were made by [Sebastian Riedel (AKA Baŝto)][basxto].

They are originally based on [Portraits and emotions][pormotion] by [Diana Paymurzina (AKA diana23570)][diana23570], which is licensed under [CC BY 4.0][cc].

It takes some inspiration from the original LPC assets, it should match after all.
Palettes are taken from https://github.com/basxto/lpc-spritesheet-collection.

Big thanks to wekhter for helping me out with base head proportions.



[lpcport]: https://opengameart.org/content/lpc-portraits-remix
[pormotion]: https://opengameart.org/content/portraits-and-emotions
[modhead]: https://opengameart.org/content/lpc-modular-bodies-and-heads

[basxto]: https://opengameart.org/users/ba%C5%9Dto
[diana23570]: https://opengameart.org/users/diana23570

[cc]: https://creativecommons.org/licenses/by-sa/3.0/